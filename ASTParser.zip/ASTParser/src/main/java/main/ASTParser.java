package main;

//imports necessary packages
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.HashSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.ArrayList;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;



public class ASTParser {
	
	//main method
    public static void main(String[] args) 
    {
    	//stores path to XML file
        String xmlFilePath = "PATH TO XML FILE GOES HERE";
        //stores data from XML file in content and runs searchForIdentifierValue with content
        try 
        {
            String content = new String(Files.readAllBytes(Paths.get(xmlFilePath)));
            searchForIdentifierValue(content);
        } 
        catch (IOException e) {
            System.err.println("Error reading the XML file: " + e.getMessage());
        }
    }

    // searchForIdentifierValue method adjusted for two separate ArrayLists
    public static void searchForIdentifierValue(String content) {
        // Pattern to match Import Declarations
        Pattern importPattern = Pattern.compile("ImportDeclaration.*?identifier='([^']*)'", Pattern.DOTALL);
        Matcher importMatcher = importPattern.matcher(content);
        
        // Pattern to match all Identifiers
        Pattern identifierPattern = Pattern.compile("identifier='([^']*)'", Pattern.CASE_INSENSITIVE);
        Matcher identifierMatcher = identifierPattern.matcher(content);
        
        //Creates HashSet to determine if identifiers show up more than once
        HashSet<String> uniqueIdentifiers = new HashSet<String>();
        
        //Creates ArrayLists to store imports and identifiers
        ArrayList<String> imports = new ArrayList<String>();
        ArrayList<String> identifiers = new ArrayList<String>();

        // Find and add all import declarations
        while (importMatcher.find()) 
        {
            String importItem = importMatcher.group(1);
            if (!imports.contains(importItem)) 
            {
                imports.add(importItem);
            }
        }

        // Find all identifiers
        while (identifierMatcher.find()) 
        {
            String identifier = identifierMatcher.group(1);
            // Add to identifiers if it's not an import and not already added
            if (!imports.contains(identifier) && uniqueIdentifiers.add(identifier)) 
            {
                identifiers.add(identifier);
            }
        }

        // Print Imports and sends details to txt files
        if (!imports.isEmpty()) 
        {
            System.out.println("Imports (information on imports stored in txt files):");
            for (String importItem : imports) 
            {
                System.out.println(importItem);
                printIdentifierDescription(importItem);
            }
        }
        
        System.out.println();
        // Print Identifiers not listed in the imports
        if (!identifiers.isEmpty()) 
        {
            System.out.println("Identifiers:");
            for (String identifier : identifiers) 
            {
                System.out.println(identifier);
            }
        }
    }
    
    
    // printIdentifierDescription method that takes in a string
    private static void printIdentifierDescription(String identifier) {
        // URL to the Java documentation for the class
        String url = "https://docs.oracle.com/javase/8/docs/api/java/util/" + identifier + ".html";
        String outputFileName = identifier + "-description.txt"; // File name for output

        try {
            // Fetch and parse the HTML content from the URL
            Document doc = Jsoup.connect(url).get();
            
            // Extract the text content
            String textContent = doc.text();
            
            // Find the start and end indices for the desired text extraction
            int startIndex = textContent.indexOf("java.util");
            int endIndex = textContent.indexOf("See Also");
            
            // Extract the text from "java.util" to "See Also"
            if (startIndex != -1 && endIndex != -1 && startIndex < endIndex) 
            {
                // Extract the specific portion of the text
                textContent = textContent.substring(startIndex, endIndex);
            } 
            else 
            {
                textContent = "Relevant documentation section not found.";
            }
            
            // Write the extracted text to a file in the current working directory
            Files.write(Paths.get(outputFileName), 
            		textContent.getBytes(StandardCharsets.UTF_8), StandardOpenOption.CREATE);
        } catch (IOException e) 
        {
            System.err.println("Error fetching the web page or writing to the output file: " + e.getMessage());
        }
    }
}
